
function checkFluency(){
        var checkbox = document.getElementById('id-of-input');
        if (checkbox.checked != true){

            /*
            var allData = {"clicked_liked":true}
            $.ajax({ type: 'post' ,
                url: '/blog-detail.html' ,
                dataType : 'html' ,
                data : allData,
                success: function(data) {
                    $("#id-of-input").html(data);
                }
            });
            */
            alert("you need to be fluent in English to apply for the job");
            $('#myforms').submit();
        }
    }