    function myFunction(x) {
        x.toggleClass("fas fa-heart");
    }
