$(function() {
  $(".heart").on("click", function() {
    $(this).toggleClass("is-active");
  });
});