import pandas as pd

pd.read_csv(r"C:\workplace\volunknig\대학현황.csv", encoding='utf-8', engine='python')