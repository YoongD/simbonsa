#import SQLAlchemy as SQLAlchemy
from flask import Flask, render_template,request
#from flask_sqlalchemy import SQLAlchemy
from flask_admin import Admin

from flask import Flask
import sqlite3
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)
#app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///testuser.db'
#app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True

#db = SQLAlchemy(app)
admin = Admin(app)


"""
class Content(db.Model):
    __tablename__ = 'content'

    id = db.Column(db.String, primary_key=True)
    title = db.Column(db.VARCHAR, nullable=False)
    recruit_office = db.Column(db.VARCHAR)
    recruit_startdate = db.Column(db.VARCHAR)
    recruit_enddate = db.Column(db.VARCHAR)
    activity_startdate = db.Column(db.VARCHAR)
    activity_enddate = db.Column(db.VARCHAR)
    contents = db.Column(db.Text)
    category = list(db.Column(db.Integer) for i in range(22))
    likecount = db.Column(db.Integer, default=0)
    receiver_disabled = db.Column(db.Integer)

place
contents   recruit_startdate   recruit_enddate   activity_date   category_life   category_world   category_environment   category_human   category_disaster   category_country   category_home   category_medic   category_education   category_administration   category_consulting   category_culture   category_physical   category_history   category_circles   category_travel   category_marketign   category_social   category_plan   category_language   category_scene   category_etc   recruit_disabled   recurit_oldman   recruit_foreigner   recruit_homeless   recruit_multiculture   recruit_worker   recruit_baby   recruit_women   recruit_zzokbang   recruit_teenager   recruit_nation   city1   city2   address   latitude   longitude
"""

#    pwd = db.Column(db.String, nullable=False)
def classification(categories):
    category_num = 22
    receiver_cate_num = 11
#    category_names = []
#    category_receivers = []
    category_names = ''
    category_receivers = ''

    category_dict = {0:'생활편의', 1:'국제협력', 2:'환경', 3:'인권', 4:'재해/재난', 5:'농어촌', 6:'주거환경', 7:'보건의료',
                     8:'교육', 9:'행정지원', 10:'상담', 11:'문화', 12:'체육', 13:'역사', 14:'동아리', 15:'여행', 16:'홍보',
                    17:'사회공헌', 18:'기획', 19:'언어', 20:'현장', 21:'기타'}
    receiver_dict = {0:'장애인', 1:'노인', 2:'외국인', 3:'노숙인', 4:'다문화가정', 5:'노동자', 6:'유아', 7:'여성', 8:'쪽방촌', 9:'청소년', 10:'지역사회'}


    #생활 편의	국제 협력	환경	인권	재해/재난	농어촌	주거 환경	보건 의료	교육	행정 지원	상담
    # 문화	체육	역사	동아리	여행	홍보	사회공헌	기획	언어	현장	기타
    # 장애인	노인	외국인	노숙인	다문화가정	노동자	유아	여성	쪽방촌	청소년	지역사회
    for i in range(category_num):
        if categories[i] > 0:
            category_names += category_dict[i] + ', '
        if i == category_num - 1:  # 맨마지막 index일 때
            if category_names[-2:] == ', ':
                category_names = category_names[:-2]

    for i in range(receiver_cate_num):
        if categories[category_num+i] > 0:
            category_receivers += receiver_dict[i] + ', '
        if i == receiver_cate_num-1:  # 맨마지막 index일 때 맨 뒤에 ','빼기
            if category_receivers[-2:] == ', ':
                category_receivers = category_receivers[:-2]

    return category_names, category_receivers  # 문자열로 return


def maxuser(index, user_matrix, content_matrix):

    # 코사인 유사도기법을 사용하면 결과 값이 튜플로 나옴
    # 튜플 -> list로 변경시켜주고,
    # sort를 위해 index를 추가해준다.
    reverse_cos=cosine_similarity(user_matrix,content_matrix)
    reverse_list=reverse_cos[index].tolist()

    new_list=[]
    for i in range(len(reverse_list)):
        new_list.append([reverse_list[i],i])
    new_list.sort(reverse=True)
    # 상위 5개만 뽑아라
    return new_list[:5]


@app.route('/user_detail')
def user_detail():
    # db 연결
    conn = sqlite3.connect('bongsa.db')
    cur = conn.cursor()
    #
    #   컨텐츠 카테고리 매트릭스 만들기
    #
    vol_list=[]
    vol_content=[]
    cur.execute("select * from volunteer")
    vol_row = cur.fetchall()
    for i in range(len(vol_row)):
        row_list = list(vol_row[i][8:30])
        row_content = list(vol_row[i][1:8])
        vol_list.append(row_list)
        vol_content.append(row_content)

    #
    #   유저 카테고리 매트릭스 만들기
    #
    cur.execute("select * from user_category")  # content_id에 해당하는 컨텐츠 가져오기
    user_row = cur.fetchall()
    # print(user_row)
    user_list = []

    # 유저카테고리 1:23
    # 튜플인 데이터를 유저매트릭스에 저장하기
    for i in range(len(user_row)):
        row_list=list(user_row[i][1:23])
        user_list.append(row_list)
    # print(user_list)


    # 부탁해요~~~
    # maxuser( logined_user_index. user_matrix, volunteer_matrix
    # 로그인 안된것도 처리를 하면 된다!
    similar_list = maxuser(3, user_list,vol_list)
    print(vol_content[similar_list[0][1]][0])
    print(similar_list[0][1])
    return render_template('user_detail.html',vol_content=vol_content,similar_list=similar_list)

#@app.route('/<contents_id>')


@app.route('/like/<path>')
def like(path=None):
    print(path)


@app.route('/')
def blog_detail():
    # db 연결
    conn = sqlite3.connect('bongsa.db')
    cur = conn.cursor()

    # query
    cur.execute("select * from volunteer") # content_id에 해당하는 컨텐츠 가져오기

    # data fetch
    row = cur.fetchone()
    category_names, category_receivers = classification(row[8:-5])
#    for row in rows:
#        print(row)

    # 봉사대상, 봉사분류
    if len(category_receivers) == 0:
        category_receivers = '전체시민'
    if len(category_names) == 0:
        category_names = ''
    conn.close()

    return render_template('blog-detail.html', contents=row, category_receiver = category_receivers,
                           category_name = category_names)

if __name__ == '__main__':
    app.run()
